Map made by GM_motion
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Thank you for downloading this map! I hope you enjoy it! Just be aware that I am working on this map a lot so this file may become outdated. 
If there is anything that you notice wrong about the map then email me at jkstanw09@gmail.com and if there is anythings you would like to be added to the map then just email me it!
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
INSTALLATION INSTRUCTIONS
Just copy the map file into your maps folder inside gmod. Just liek that! It should pop up in the other tab or you can type in map hangoutV6 in the
console to load the map, the version might be higher in the future. So just put the version that is in the name of the file.