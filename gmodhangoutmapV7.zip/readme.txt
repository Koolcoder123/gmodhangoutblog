Thank you for downloading this map, made by Trooper! I think this map is going to be more for half life 2 than gmod.
------------------------------------------------------------------------------------------------------------------------------------------
HOW TO INSTALL
Just put the map in your half life 2 or gmod maps section, in gmod it will appear in the other section. In half life 2 you need to type "map hangoutV7" in the console to load the map.
------------------------------------------------------------------------------------------------------------------------------------------


        Enjoy!
                   -Trooper